CREATE PROCEDURE pr_add(IN a INT(10), IN b INT(10))
  begin
   declare  c int;
   if a is null then
      set a = 0;
   end if;
   if b is null then
      set b = 0;
   end if;
   set c = a + b;
   select c as sum;
end;
