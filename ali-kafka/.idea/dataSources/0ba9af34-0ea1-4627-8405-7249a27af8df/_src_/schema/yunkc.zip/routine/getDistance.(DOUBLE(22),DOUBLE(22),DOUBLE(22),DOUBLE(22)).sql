CREATE FUNCTION getDistance(lat1 DOUBLE(22), lng1 DOUBLE(22), lat2 DOUBLE(22), lng2 DOUBLE(22))
  RETURNS DOUBLE
  begin
	declare radLat1 double;
		declare radLat2 double;
		declare a double;
		declare b double;
		declare s double;
		declare RAD double;
		set RAD=PI()/180;
		set radLat1 = lat1 * RAD;
		set radLat2 = lat2 * RAD;
		set a = radLat1 - radLat2;
		set b = (lng1 - lng2) * RAD;
		set s = 2 * ASIN(SQRT(POW(SIN(a / 2), 2) + COS(radLat1) * COS(radLat2)
				* POW(SIN(b / 2), 2)));
		set s = s * 6378137;
		set s = ROUND(s * 10000) / 10000;
	RETURN s;	

end;
