CREATE PROCEDURE tradeIdleHandler()
  BEGIN
	DECLARE done int;

	DECLARE cur_id varchar(255);
	 
	DECLARE cursor_cols CURSOR FOR SELECT id FROM charging_record where TIMESTAMPDIFF(SECOND,end_time,now())>30 and trade_status='8';
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

	OPEN cursor_cols;
  
		cursor_cols:LOOP
		 
			 FETCH cursor_cols INTO cur_id;
             
             if done=1 then

             leave cursor_cols;

			 end if;
       
		update charging_record set trade_status='9' where id=cur_id;
	END LOOP cursor_cols; 	
	CLOSE cursor_cols;


END;
