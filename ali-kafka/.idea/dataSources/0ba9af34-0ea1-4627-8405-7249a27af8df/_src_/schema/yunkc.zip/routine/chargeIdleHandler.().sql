CREATE PROCEDURE chargeIdleHandler()
  BEGIN
	DECLARE done int;

	DECLARE cur_id varchar(255);
	 
	DECLARE cursor_cols CURSOR FOR SELECT id FROM charging_record where TIMESTAMPDIFF(SECOND,start_time,now())>60 and (trade_status in('1','4') or trade_status is null);
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

	OPEN cursor_cols;
  
		cursor_cols:LOOP
		 
			 FETCH cursor_cols INTO cur_id;
             
             if done=1 then

             leave cursor_cols;

			 end if;
       
		update charging_record set trade_status='3',fail_reason='0020'  where id=cur_id;
	END LOOP cursor_cols; 	
	CLOSE cursor_cols;


END;
