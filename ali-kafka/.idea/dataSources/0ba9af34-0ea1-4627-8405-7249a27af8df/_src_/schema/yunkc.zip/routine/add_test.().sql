CREATE PROCEDURE add_test()
  BEGIN
           #定义 变量
           DECLARE a DOUBLE(40,6);
           DECLARE b DOUBLE(40,6);
           DECLARE c INT(32);
	   DECLARE X DOUBLE(40,6);
	   DECLARE Y DOUBLE(40,6);
	   DECLARE z DOUBLE(40,6);
	   DECLARE theta DOUBLE(40,6);
	   DECLARE gg_lon DOUBLE(40,6);
	   DECLARE gg_lat DOUBLE(40,6);
	   DECLARE PI DOUBLE (40,6);
	   DECLARE x_pi DOUBLE (40,6);
           #这个用于处理游标到达最后一行的情况
           DECLARE s INT DEFAULT 0;
           #声明游标cursor_name（cursor_name是个多行结果集）
           DECLARE cursor_name CURSOR FOR SELECT longitude,latitude,id FROM charging_station;
           #设置一个终止标记
           DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET s=1;
            #SET str = "--";
               SET PI = 3.14159265358979324;
	   SET x_pi = 3.1415926535897932384626 * 3000.0 / 180.0;
                #打开游标
                OPEN cursor_name;
                    #获取游标当前指针的记录，读取一行数据并传给变量a,b
                    FETCH  cursor_name INTO a,b,c;
                    #开始循环，判断是否游标已经到达了最后作为循环条件
                    WHILE s <> 1 DO
                            #SET str =  CONCAT(str,X);
                            SET X = a - 0.0065;
                            SET  Y = b - 0.006;
			    SET z = SQRT(X * X + Y * Y) - 0.00002 * SIN(Y * x_pi);
			    SET theta = ATAN2(Y, X) - 0.000003 * COS(X * x_pi);
			    SET gg_lon = z * COS(theta);
			    SET gg_lat = z * SIN(theta);
                            UPDATE charging_station t SET t.`longitude_gcj` =gg_lon,t.`latitude_gcj`=gg_lat WHERE id =c;
                            #读取下一行的数据
                            FETCH  cursor_name INTO a,b,c;
                    END WHILE;
                 #关闭游标
                CLOSE cursor_name ;
            #SELECT str;
    #语句执行结束
    END;
