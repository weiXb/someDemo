CREATE PROCEDURE xici_update()
  begin

update charging_station set station_status=if(station_status='1','0','1') where id='69';

end;
