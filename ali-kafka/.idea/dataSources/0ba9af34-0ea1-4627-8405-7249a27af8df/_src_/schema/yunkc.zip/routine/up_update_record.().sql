CREATE PROCEDURE up_update_record()
  begin

 

update charging_record a
   set `trade_status`= '9',
       `fail_reason`= '66'
 where `trade_status`= '7'
   and TIMESTAMPDIFF(SECOND, date_add(`start_time`, interval `charged_time` second), now())> 300;

end;
