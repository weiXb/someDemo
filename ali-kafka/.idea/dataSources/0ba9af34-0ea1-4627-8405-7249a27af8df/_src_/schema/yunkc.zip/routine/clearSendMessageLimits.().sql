CREATE PROCEDURE clearSendMessageLimits()
  begin

TRUNCATE TABLE send_message_times;

update `charging_pile`  set `pile_status` =0,`update_time` = null;

end;
