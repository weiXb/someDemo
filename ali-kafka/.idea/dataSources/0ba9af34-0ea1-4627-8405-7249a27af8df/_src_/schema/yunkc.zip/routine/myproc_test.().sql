CREATE PROCEDURE myproc_test()
  begin  
declare i int;  #定义j变量  
set i=1;  
    while(i<=1000000) do   #对课程号的循环  
INSERT INTO `finance_accountflow`
VALUES
	(
		UUID(),
		'480',
		'20161214201938314480',
		NULL,
		'14',
		'32010200000043121612141908401384',
		'2016-12-14 20:19:38',
		'-32.06',
		'19.22',
		'0.0',
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		'1',
		'0',
		NULL,
		NULL
	);
    set i=i+1;  
    end while;  
end;
