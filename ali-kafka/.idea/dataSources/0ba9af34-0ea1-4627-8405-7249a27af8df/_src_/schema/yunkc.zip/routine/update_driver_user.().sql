CREATE PROCEDURE update_driver_user()
  BEGIN
	DECLARE done int;

	DECLARE cur_id varchar(255);
	 
	DECLARE cursor_cols CURSOR FOR SELECT ut.phone FROM user_info_todeal ut inner join normal_user u  on u.phone=ut.phone where ut.phone!='' and TIMESTAMPDIFF(SECOND,u.regDate,now())<=60;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

	OPEN cursor_cols;
  
		cursor_cols:LOOP
		 
			 FETCH cursor_cols INTO cur_id;
             
             if done=1 then

             leave cursor_cols;

			 end if;
		update normal_user u left join user_info_todeal ut on u.phone=ut.phone  set u.remark=ut.platenum ,u.company_id=ut.company,u.name=ut.name   where u.phone=cur_id;
	END LOOP cursor_cols; 	
	CLOSE cursor_cols;


END;
