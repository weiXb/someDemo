CREATE PROCEDURE createRBS()
  BEGIN
		DECLARE done int;

	DECLARE cur_id varchar(255);
	 
	DECLARE cursor_cols CURSOR FOR select id from `charging_station` where `del_flag` ='0';
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

	OPEN cursor_cols;
  
		cursor_cols:LOOP
		 
			 FETCH cursor_cols INTO cur_id;
             
             if done=1 then

             leave cursor_cols;

			 end if;
		 insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'1',cur_id);
	     insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'2',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'3',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'4',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'5',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'6',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'7',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'8',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'9',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'10',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'11',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'12',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'13',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'14',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'15',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'16',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'17',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'18',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'19',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'20',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'21',cur_id);
	 insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'22',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'23',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'24',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'25',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'26',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'27',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'28',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'29',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'30',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'31',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'32',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'33',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'34',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'35',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'36',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'37',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'38',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'39',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'40',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'41',cur_id);
	 insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'42',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'43',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'44',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'45',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'46',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'47',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'48',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'49',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'50',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'51',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'52',cur_id);
insert into `brand_station`(id,`dict_id` ,`station_id` ) VALUES(replace(UUID(),'-',''),'53',cur_id);
	END LOOP cursor_cols; 	
	CLOSE cursor_cols;
END;
