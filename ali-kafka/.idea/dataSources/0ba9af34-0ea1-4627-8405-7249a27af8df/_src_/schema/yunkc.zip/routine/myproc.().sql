CREATE PROCEDURE myproc()
  BEGIN
	DECLARE
		num INT ;
	SET num = 1 ;
	WHILE num <= 30 DO
		INSERT INTO `charging_record_history` (`trade_seq`, `uid`, `pile_id`, `pile_number`, `start_time`, `end_time`, `true_start_time`, `true_end_time`, `trade_time`, `pile_v`, `pile_a`, `end_flag`, `peak_power`, `peak_price`, `top_power`, `top_price`, `flat_power`, `flat_price`, `valley_power`, `valley_price`, `parking_price`, `charged_time`, `charged_power`, `ratio`, `charged_price`, `charged_price_ori`, `station_ratio`, `parking_ratio`, `loss_ratio`, `discount`, `usefull_consume`, `card_consume`, `consume`, `left_time`, `start_soc`, `soc`, `highest_temp`, `lowest_temp`, `parked_price`, `parked_price_ori`, `trade_status`, `fail_reason`, `charging_source`, `del_flag`, `gift_flag`, `battery_temperature`, `vin`, `up_sign`, `service_ratio`, `scheme_id`) VALUES ('32010200000000011610241433510005', '524', '46', '3201020000000101', '2016-10-24 14:34:09', '2016-10-24 14:34:19', '1999-11-30 00:00:00', '1999-11-30 00:00:00', '2016-10-24 14:34:18', NULL, NULL, NULL, '0', '1.2', '0', '1.2', '0', '1.2', '0', '1.2', '0', '0', '0.0', '1.0', '0.0', '0.0', '0.75', '1', '0', '0', '0', '0', '0.00', NULL, '0', '20', '0', '1', '0.00', '0.00', '10', '', '1', '0', '1', '10', NULL, NULL, '1', NULL);


	SET num = num + 1 ;
	END
	WHILE ;
	END;
