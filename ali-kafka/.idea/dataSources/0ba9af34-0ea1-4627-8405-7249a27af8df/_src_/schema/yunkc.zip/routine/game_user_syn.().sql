CREATE PROCEDURE game_user_syn()
  BEGIN
     insert into  `game_user`(uid,phone,`password` ,`name` ,`register_source` ,`login_flag` ) 
     SELECT u.id,u.phone,u.password,u.name,'0','0' FROM `normal_user` u where TIMESTAMPDIFF(SECOND,u.`regDate`,now())<=30
     and  not EXISTS (select * from game_user gu where gu.uid=u.id);

END;
