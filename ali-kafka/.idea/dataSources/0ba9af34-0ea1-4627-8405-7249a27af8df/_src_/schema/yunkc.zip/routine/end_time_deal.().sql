CREATE PROCEDURE end_time_deal()
  BEGIN
	DECLARE done int;
	DECLARE cur_id varchar(255);
	DECLARE cur_time datetime;
	 
	DECLARE cursor_cols CURSOR FOR SELECT id,time FROM `end_charging`;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

	OPEN cursor_cols;
  
		cursor_cols:LOOP
		 
			 FETCH cursor_cols INTO cur_id,cur_time;
             
             if done=1 then

             leave cursor_cols;

			 end if;
       update charging_record set `end_time` =cur_time where id=cur_id;
	END LOOP cursor_cols; 	
	CLOSE cursor_cols;
END;
