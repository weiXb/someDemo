CREATE FUNCTION func_get_splitStringTotal(f_string VARCHAR(10000), f_delimiter VARCHAR(50))
  RETURNS INT
  BEGIN 
return (length(f_string) - length(replace(f_string,f_delimiter,'')))-1; 
END;
