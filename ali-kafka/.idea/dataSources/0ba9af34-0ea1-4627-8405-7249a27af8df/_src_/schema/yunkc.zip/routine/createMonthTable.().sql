CREATE PROCEDURE createMonthTable()
  BEGIN
set @tname1 = concat('pile_ln_up',date_format(now(),'%y%m'));
set @tname2 = concat('pile_remote_measurement',date_format(now(),'%y%m'));
set @tname3 = concat('pile_remote_signalling',date_format(now(),'%y%m'));
set @tname4 = concat('pile_dpower_history',date_format(now(),'%y%m'));
set @sql1 = concat('CREATE TABLE IF NOT EXISTS ',@tname1,' (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `log_time` datetime DEFAULT NULL,
  `log_data` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8'); 
 set @sql2=concat('CREATE TABLE IF NOT EXISTS ',@tname2,'(
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insert_time` datetime DEFAULT NULL,
  `content_length` int(11) DEFAULT NULL,
  `up_flag` int(11) DEFAULT NULL,
  `down_flag` int(11) DEFAULT NULL,
  `transmision_cause` int(11) DEFAULT NULL,
  `pile_number` varchar(64) DEFAULT NULL,
   `trade_no` varchar(64) DEFAULT NULL,
  `pile_v` double(255,3) DEFAULT NULL,
  `pile_a` double(255,3) DEFAULT NULL,
  `charge_model` varchar(255) DEFAULT NULL,
  `soc` varchar(64) DEFAULT NULL,
  `lowest_temp` varchar(64) DEFAULT NULL,
  `highest_temp` varchar(64) DEFAULT NULL,
  `charged_time` varchar(64) DEFAULT NULL,
  `charge_status` varchar(255) DEFAULT NULL,
  `left_time` varchar(8) DEFAULT NULL,
  `highest_v` varchar(32) DEFAULT NULL,
  `highest_v_location` varchar(32) DEFAULT NULL,
   `fault` varchar(8) DEFAULT NULL,         
  `del_flag` char(1) default 0 ,
  PRIMARY KEY (`id`),
   INDEX m_pn(pile_number),
    INDEX m_td(trade_no)            
) ENGINE=InnoDB DEFAULT CHARSET=utf8');
set @sql3=concat('CREATE TABLE IF NOT EXISTS  ',@tname3,'(
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insert_time` datetime DEFAULT NULL,
  `content_length` int(11) DEFAULT NULL,
  `up_flag` int(11) DEFAULT NULL,
  `down_flag` int(11) DEFAULT NULL,
  `transmision_cause` int(11) DEFAULT NULL,
  `pile_number` varchar(64) DEFAULT NULL,
   `trade_no` varchar(64) DEFAULT NULL,
  `bms_fault` varchar(64) DEFAULT NULL,
  `overtemp_fault` varchar(64) DEFAULT NULL,
  `hardware_fault` varchar(64) DEFAULT NULL,
  `normal_end` varchar(64) DEFAULT NULL,
  `connecting_status` varchar(2) DEFAULT NULL,
  `del_flag` char(1) default 0,
  PRIMARY KEY (`id`),
   INDEX r_pn(pile_number),
    INDEX r_td(trade_no)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8');
set @sql4=concat('CREATE TABLE IF NOT EXISTS  ',@tname4,'(
 `id` int(11) NOT NULL AUTO_INCREMENT,
  `insert_time` datetime DEFAULT NULL,
  `content_length` int(11) DEFAULT NULL,
  `up_flag` int(11) DEFAULT NULL,
  `down_flag` int(11) DEFAULT NULL,
  `transmision_cause` int(11) DEFAULT NULL,
  `pile_number` varchar(64) DEFAULT NULL,
   `trade_no` varchar(64) DEFAULT NULL,              
  `pile_kw` double(8,2) DEFAULT NULL,
  `consume` double(8,2) DEFAULT NULL,
  `del_flag` char(1) default 0,
  PRIMARY KEY (`id`),
   INDEX p_pn(pile_number),
    INDEX p_td(trade_no)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8');
prepare s1 from @sql1;
execute s1;
prepare s2 from @sql2;
execute s2;
prepare s3 from @sql3;
execute s3;
prepare s4 from @sql4;
execute s4;
PREPARE prod FROM 'INSERT INTO backupHistoryTab(tableName1,tableName2,tableName3,tableName4,createTime) VALUES (?,?,?,?,?)'; 
set @createtime = now();
execute prod using @tname1,@tname2,@tname3,@tname4,@createtime;
END;
