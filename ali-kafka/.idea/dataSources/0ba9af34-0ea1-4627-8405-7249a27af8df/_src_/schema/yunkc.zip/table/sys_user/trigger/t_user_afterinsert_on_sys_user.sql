CREATE TRIGGER t_user_afterinsert_on_sys_user
AFTER INSERT ON sys_user
FOR EACH ROW
  BEGIN
     insert into t_master_data_modify_info(tableName,pkName,pkValue) values('sys_user','ID',new.ID);
END;
