CREATE TRIGGER t_user_afterupdate_on_charging_station
AFTER UPDATE ON charging_station
FOR EACH ROW
  BEGIN
      insert into t_master_data_modify_info(tableName,pkName,pkValue) values('charging_station','ID',old.ID);
END;
