CREATE TRIGGER t_user_afterupdate_on_sys_user
AFTER UPDATE ON sys_user
FOR EACH ROW
  BEGIN
      IF
         old.company_id <> new.company_id ||
         old.login_name <> new.login_name ||
         old.password <> new.password ||
         old.name <> new.name ||
         old.mobile <> new.mobile ||
         old.email <> new.email ||
         old.remarks <> new.remarks ||
         old.del_flag <> new.del_flag          
      THEN
       insert into t_master_data_modify_info(tableName,pkName,pkValue) values('sys_user','ID',old.ID);
      END IF;
END;
