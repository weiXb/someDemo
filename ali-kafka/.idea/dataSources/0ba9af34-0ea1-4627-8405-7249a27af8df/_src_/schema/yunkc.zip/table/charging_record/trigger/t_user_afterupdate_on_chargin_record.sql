CREATE TRIGGER t_user_afterupdate_on_chargin_record
BEFORE UPDATE ON charging_record
FOR EACH ROW
  begin

	if
    	new.trade_status = 1 and new.isOrNoAuthentication = 1
      THEN
       #update charging_record set trade_status = 2 where new.isOrNoAuthentication = 1 and new.trade_status = 1;
       set new.trade_status=2;
      END IF;

end;
