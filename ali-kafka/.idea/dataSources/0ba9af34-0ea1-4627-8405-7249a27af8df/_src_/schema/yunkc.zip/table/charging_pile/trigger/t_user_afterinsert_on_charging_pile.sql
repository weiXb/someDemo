CREATE TRIGGER t_user_afterinsert_on_charging_pile
AFTER INSERT ON charging_pile
FOR EACH ROW
  BEGIN
     insert into t_master_data_modify_info(tableName,pkName,pkValue) values('charging_pile','ID',new.ID);
END;
