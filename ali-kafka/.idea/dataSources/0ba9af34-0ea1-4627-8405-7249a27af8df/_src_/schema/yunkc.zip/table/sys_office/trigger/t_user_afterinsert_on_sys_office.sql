CREATE TRIGGER t_user_afterinsert_on_sys_office
AFTER INSERT ON sys_office
FOR EACH ROW
  BEGIN
     insert into t_master_data_modify_info(tableName,pkName,pkValue) values('sys_user','ID',new.ID);
END;
