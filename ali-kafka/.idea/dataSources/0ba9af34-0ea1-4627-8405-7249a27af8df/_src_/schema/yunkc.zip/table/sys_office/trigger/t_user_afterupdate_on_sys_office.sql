CREATE TRIGGER t_user_afterupdate_on_sys_office
AFTER UPDATE ON sys_office
FOR EACH ROW
  BEGIN
      IF 
         old.parent_id <> new.parent_id ||
         old.parent_ids <> new.parent_ids ||
         old.name <> new.name ||
         old.code <> new.code ||
         old.province_code <> new.province_code ||
         old.city_code <> new.city_code ||
         old.district_code <> new.district_code ||
         old.type <> new.type ||
         old.address <> new.address ||
         old.master <> new.master ||
         old.phone <> new.phone ||
         old.logo_image <> new.logo_image ||
         old.app_logo_image <> new.app_logo_image ||
         old.app_logo_white_image <> new.app_logo_white_image ||
         old.del_flag <> new.del_flag  
      THEN
      insert into t_master_data_modify_info(tableName,pkName,pkValue) values('sys_office','ID',old.ID);
      END IF;
END;
