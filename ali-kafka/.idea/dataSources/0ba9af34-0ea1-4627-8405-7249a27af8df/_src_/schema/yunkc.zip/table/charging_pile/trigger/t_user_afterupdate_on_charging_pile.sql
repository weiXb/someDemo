CREATE TRIGGER t_user_afterupdate_on_charging_pile
AFTER UPDATE ON charging_pile
FOR EACH ROW
  BEGIN
      IF
         old.pile_brand <> new.pile_brand ||
         old.pile_name <> new.pile_name ||
         old.pile_number <> new.pile_number ||
         old.station_id <> new.station_id ||
         old.pile_stop <> new.pile_stop ||
         old.pile_v <> new.pile_v ||
         old.pile_a <> new.pile_a ||
         old.pile_kw <> new.pile_kw ||
         old.batch <> new.batch ||
         old.pile_sim <> new.pile_sim ||
         old.islock <> new.islock ||
         old.supply_type <> new.supply_type ||
         old.del_flag <> new.del_flag
       THEN
        insert into t_master_data_modify_info(tableName,pkName,pkValue) values('charging_pile','ID',old.ID);
      END IF;
END;
