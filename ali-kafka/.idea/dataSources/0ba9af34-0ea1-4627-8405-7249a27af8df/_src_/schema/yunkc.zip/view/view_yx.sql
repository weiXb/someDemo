CREATE VIEW view_yx AS
  SELECT
    `yunkc`.`pile_remote_signalling1603`.`id`                AS `id`,
    `yunkc`.`pile_remote_signalling1603`.`insert_time`       AS `insert_time`,
    `yunkc`.`pile_remote_signalling1603`.`content_length`    AS `content_length`,
    `yunkc`.`pile_remote_signalling1603`.`up_flag`           AS `up_flag`,
    `yunkc`.`pile_remote_signalling1603`.`down_flag`         AS `down_flag`,
    `yunkc`.`pile_remote_signalling1603`.`transmision_cause` AS `transmision_cause`,
    `yunkc`.`pile_remote_signalling1603`.`pile_number`       AS `pile_number`,
    `yunkc`.`pile_remote_signalling1603`.`bms_fault`         AS `bms_fault`,
    `yunkc`.`pile_remote_signalling1603`.`overtemp_fault`    AS `overtemp_fault`,
    `yunkc`.`pile_remote_signalling1603`.`hardware_fault`    AS `hardware_fault`,
    `yunkc`.`pile_remote_signalling1603`.`normal_end`        AS `normal_end`,
    `yunkc`.`pile_remote_signalling1603`.`connecting_status` AS `connecting_status`
  FROM `yunkc`.`pile_remote_signalling1603`;
