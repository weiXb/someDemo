CREATE VIEW view_record AS
  SELECT
    `a`.`id`              AS `id`,
    `a`.`trade_seq`       AS `trade_seq`,
    `a`.`uid`             AS `uid`,
    `a`.`pile_id`         AS `pile_id`,
    `a`.`pile_number`     AS `pile_number`,
    `a`.`start_time`      AS `start_time`,
    `a`.`end_time`        AS `end_time`,
    `a`.`true_start_time` AS `true_start_time`,
    `a`.`true_end_time`   AS `true_end_time`,
    `a`.`trade_time`      AS `trade_time`,
    `a`.`pile_v`          AS `pile_v`,
    `a`.`pile_a`          AS `pile_a`,
    `a`.`end_flag`        AS `end_flag`,
    `a`.`peak_price`      AS `peak_price`,
    `a`.`top_price`       AS `top_price`,
    `a`.`flat_price`      AS `flat_price`,
    `a`.`valley_price`    AS `valley_price`,
    `a`.`parking_price`   AS `parking_price`,
    `a`.`charged_time`    AS `charged_time`,
    `a`.`charged_power`   AS `charged_power`,
    `a`.`charged_price`   AS `charged_price`,
    `a`.`left_time`       AS `left_time`,
    `a`.`soc`             AS `soc`,
    `a`.`parked_price`    AS `parked_price`,
    `a`.`trade_status`    AS `trade_status`,
    `a`.`fail_reason`     AS `fail_reason`,
    `a`.`charging_source` AS `charging_source`,
    `b`.`station_id`      AS `station_id`,
    `c`.`s_name`          AS `s_name`,
    `b`.`pile_name`       AS `pile_name`,
    `e`.`id`              AS `eid`,
    `e`.`name`            AS `ename`,
    `d`.`phone`           AS `phone`,
    `d`.`name`            AS `dname`,
    `f`.`cardno`          AS `cardno`
  FROM (((
      ((`yunkc`.`charging_record` `a` LEFT JOIN `yunkc`.`charging_pile` `b` ON ((`a`.`pile_id` = `b`.`id`))) LEFT JOIN
        `yunkc`.`charging_station` `c` ON ((`b`.`station_id` = `c`.`id`))) LEFT JOIN `yunkc`.`normal_user` `d`
        ON ((`a`.`uid` = `d`.`id`))) LEFT JOIN `yunkc`.`sys_office` `e` ON ((`d`.`company_id` = `e`.`id`))) LEFT JOIN
    `yunkc`.`cs_smart_card` `f` ON ((`d`.`id` = `f`.`normaluserid`)));
