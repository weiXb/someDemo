CREATE VIEW view_yc AS
  SELECT
    `yunkc`.`pile_remote_measurement1605`.`id`                 AS `id`,
    `yunkc`.`pile_remote_measurement1605`.`insert_time`        AS `insert_time`,
    `yunkc`.`pile_remote_measurement1605`.`content_length`     AS `content_length`,
    `yunkc`.`pile_remote_measurement1605`.`up_flag`            AS `up_flag`,
    `yunkc`.`pile_remote_measurement1605`.`down_flag`          AS `down_flag`,
    `yunkc`.`pile_remote_measurement1605`.`transmision_cause`  AS `transmision_cause`,
    `yunkc`.`pile_remote_measurement1605`.`pile_number`        AS `pile_number`,
    `yunkc`.`pile_remote_measurement1605`.`pile_v`             AS `pile_v`,
    `yunkc`.`pile_remote_measurement1605`.`pile_a`             AS `pile_a`,
    `yunkc`.`pile_remote_measurement1605`.`charge_model`       AS `charge_model`,
    `yunkc`.`pile_remote_measurement1605`.`soc`                AS `soc`,
    `yunkc`.`pile_remote_measurement1605`.`lowest_temp`        AS `lowest_temp`,
    `yunkc`.`pile_remote_measurement1605`.`highest_temp`       AS `highest_temp`,
    `yunkc`.`pile_remote_measurement1605`.`charged_time`       AS `charged_time`,
    `yunkc`.`pile_remote_measurement1605`.`charge_status`      AS `charge_status`,
    `yunkc`.`pile_remote_measurement1605`.`left_time`          AS `left_time`,
    `yunkc`.`pile_remote_measurement1605`.`highest_v`          AS `highest_v`,
    `yunkc`.`pile_remote_measurement1605`.`highest_v_location` AS `highest_v_location`
  FROM `yunkc`.`pile_remote_measurement1605`;
